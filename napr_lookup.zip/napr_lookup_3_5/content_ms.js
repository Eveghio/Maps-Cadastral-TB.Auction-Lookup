// Runs on ms.gov.ge/msmap. Draws parcels by using the site's own search: type the code,
// click the "registered land parcels" result. The site keeps those outlines (keepResult),
// so several codes accumulate on the same map.
(() => {
  if (window.__msLookupLoaded) return; // injected twice (manifest + fallback injection)
  window.__msLookupLoaded = true;

  // Hand this browser's own ms.gov.ge session token to the extension (it stays in this browser).
  // The site may renew it (e.g. after its login redirect), so keep watching for a little while.
  let lastToken = null;
  const reportToken = () => {
    let t = null;
    try { t = localStorage.getItem("session-token"); } catch (e) { /* storage blocked */ }
    if (t && t !== lastToken && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(t)) {
      lastToken = t;
      chrome.runtime.sendMessage({ type: "ms-token", token: t }).catch(() => {});
    }
  };
  reportToken();
  let checks = 0;
  const tokenTimer = setInterval(() => { reportToken(); if (++checks >= 15) clearInterval(tokenTimer); }, 2000);
  window.addEventListener("storage", reportToken);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const waitFor = async (fn, timeoutMs) => {
    for (let t = 0; t < timeoutMs; t += 250) {
      const v = fn();
      if (v) return v;
      await sleep(250);
    }
    return null;
  };

  async function drawOne(code) {
    const input = await waitFor(() => document.querySelector('input[name="searchText"].app-custom-search-input'), 20000);
    if (!input) {
      console.warn("[ms-lookup] search box not found");
      return false;
    }
    input.focus();
    input.value = code;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    for (const type of ["keydown", "keypress", "keyup"]) {
      input.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
    }
    // The NAPR row shows the code followed by "registered land parcels"; match the code exactly.
    const item = await waitFor(() =>
      [...document.querySelectorAll(".app-search-input-result-item-div")].find((d) => {
        const text = d.textContent.replace(/\s+/g, " ").trim();
        return text.split(" ")[0] === code && text.includes("რეგისტრირებული");
      }), 15000);
    if (!item) {
      console.warn(`[ms-lookup] no NAPR result row for ${code}`);
      return false;
    }
    item.click();
    // let the dropdown close and the outline render before the next code
    await waitFor(() => !document.querySelector(".app-search-input-result-item-div"), 3000);
    await sleep(300);
    console.log(`[ms-lookup] drew ${code}`);
    return true;
  }

  // One job at a time, even if a new request arrives while codes are still being drawn.
  let queue = Promise.resolve();
  function drawCodes(codes) {
    const job = queue.then(async () => {
      const drawn = [], failed = [];
      for (const code of codes) ((await drawOne(code)) ? drawn : failed).push(code);
      return { drawn, failed };
    });
    queue = job.catch(() => {});
    return job;
  }

  // "Add to the open map" requests from the extension
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "ms-draw" || !Array.isArray(message.codes)) return;
    drawCodes(message.codes).then(sendResponse);
    return true;
  });

  // A tab the extension just opened: pick up its codes
  (async () => {
    let codes = null;
    try {
      codes = await chrome.runtime.sendMessage({ type: "ms-get-pending" });
    } catch (e) {
      return;
    }
    if (!codes) return; // tab was not opened by the extension
    if (!Array.isArray(codes)) codes = [codes];
    const result = await drawCodes(codes);
    console.log("[ms-lookup] result:", JSON.stringify(result));
  })();
})();
