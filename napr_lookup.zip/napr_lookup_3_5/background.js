// NAPR Cadastral & Auction Lookup - merged extension (maps.gov.ge + ms.gov.ge + registry + auction)
//
// Actions (one name per thing the user can do; used by the popup, menus, shortcuts and history):
//   maps-map  / maps-kml   -> maps.gov.ge map (add to the open map tab / new tab) and KML files
//   ms-map    / ms-kml     -> ms.gov.ge map and KML files
//   pdf / abstract         -> NAPR extract PDF (GetBlob) / extract list page (cad_amo.php)
//   auction                -> Tbilisi auction lot

const BASE_URL = "https://abstract.reestri.gov.ge/abstract/cad_amo.php?cad_code=";
const AUCTION_URL = "http://auction.tbilisi.gov.ge/Pages/Auctions/Lot.aspx?id=";

// Cadastral codes like 01.10.12.001.001, optionally ending with ONE Georgian letter
// (e.g. 01.16.05.001.003ა). Georgian Mkhedruli range: U+10D0 (ა) .. U+10F0 (ჰ).
const CADASTRAL_REGEX = /\d+(?:\.\d+){2,9}[\u10D0-\u10F0]?/;

function extractValidCadastralCode(text) {
  if (!text) return null;
  const match = text.trim().match(CADASTRAL_REGEX);
  return match ? match[0] : null;
}

// All cadastral codes in a text, in order, without duplicates.
function extractAllCadastralCodes(text) {
  if (!text) return [];
  const all = text.match(new RegExp(CADASTRAL_REGEX.source, "g")) || [];
  return [...new Set(all)];
}

// Auction lot id = the digits the user selected (usually the tail of the contract number).
// Pure digits (spaces ignored) -> used as is; otherwise the LAST run of digits in the selection.
function extractAuctionId(text) {
  if (!text) return null;
  const t = text.trim();
  const compact = t.replace(/\s+/g, "");
  if (/^\d+$/.test(compact)) return compact;
  const runs = t.match(/\d+/g);
  return runs ? runs[runs.length - 1] : null;
}

// ---- Mode "map": open the parcel on maps.gov.ge ----
const MAP_BASE = "https://maps.gov.ge";

function flashBadge(text, color) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 3500);
}

// Same parameters the portal itself sends (map view values are irrelevant for the lookup).
function buildMapSearchBody(code) {
  const p = new URLSearchParams();
  p.set("keyword", code);
  p.append("keyword_description[coords][]", "43.50440835585885");
  p.append("keyword_description[coords][]", "42.13098999999999");
  p.set("keyword_description[zoom]", "8");
  for (const v of ["4255852.20820669", "4899638.835397534", "5429924.962666997", "5461603.86735015"]) {
    p.append("keyword_description[bbox][]", v);
  }
  p.set("keyword_description[screen_width]", "1920");
  p.set("keyword_description[screen_height]", "1080");
  p.set("keyword_description[projection]", "EPSG:4326");
  p.set("keyword_description[orientation_angle]", "0");
  p.set("keyword_description[getinfo_type]", "");
  p.append("keyword_description[layers][]", "92");
  p.append("keyword_description[layers][]", "97");
  p.set("keyword_description[lang]", "ka");
  return p;
}

// Search by cadastral code. Returns { lbl, address, geometryPath } or null if not found.
// Throws on network/format errors.
async function searchParcel(code) {
  const res = await fetch(`${MAP_BASE}/map/portal/search`, {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      "x-requested-with": "XMLHttpRequest"
    },
    body: buildMapSearchBody(code),
    credentials: "include"
  });
  if (!res.ok) throw new Error(`სერვერმა დააბრუნა HTTP ${res.status}`);

  let json;
  try {
    json = await res.json();
  } catch {
    throw new Error("პასუხი JSON არ არის (პორტალი შესაძლოა დროებით მიუწვდომელია)");
  }
  if (!json.status) throw new Error("სერვერმა status=false დააბრუნა");

  // Exact match only; never pick a "similar" record.
  const hit = (json.result || []).find((r) => r.name === code);
  if (!hit) return null;

  const details = hit.details || {};
  const link = details.info_link || hit.resultlink || "";
  // ROWID is base64 and may contain "+" and "/". URLSearchParams would turn "+" into a space,
  // so lbl is cut out of the raw string; decodeURIComponent keeps "+" as is
  // (and also handles a server that already sends it as %2B).
  const lblMatch = link.match(/[?&]lbl=([^&#]+)/);
  if (!lblMatch) throw new Error("პასუხში lbl ვერ ვიპოვე");
  let lbl;
  try {
    lbl = decodeURIComponent(lblMatch[1]); // lr_parcels:AAAr...
  } catch {
    lbl = lblMatch[1];
  }
  return {
    lbl,
    address: hit.descript || "",
    // the server hands us the ready-made geometry link (already contains &res=shp)
    // Sent exactly as the portal sends it: a literal "+" in the ROWID. The server does NOT decode
    // %2B back to "+" (it then returns an empty "data" list), so the ROWID must not be re-encoded.
    geometryPath: details.geometry_link || `/lr/bo/mg/getinfo.alpha?lbl=${lbl}&res=shp`
  };
}

// Returns the map URL, or null if the code was not found.
async function resolveMapUrl(code) {
  const parcel = await searchParcel(code);
  if (!parcel) return null;
  return mapsUrlForLbl(parcel.lbl);
}

function mapsUrlForLbl(lbl) {
  return `${MAP_BASE}/map/portal#search/result/lr/bo/mg/getinfo.alpha?lbl=${lbl}&share=1&layers=92,97`;
}


// ======================= ms.gov.ge =======================

const MS_BASE = "https://ms.gov.ge";
const MS_SEARCH_URL = MS_BASE + "/core-api/v1/search/unified-search";
// ms.gov.ge needs a session token ("sso-token" header). Nothing is hard-coded: every browser uses
// its OWN anonymous ms.gov.ge session, which content_ms.js reads from the site (localStorage
// "session-token") whenever ms.gov.ge is open, and which is refreshed automatically when it stops working.
const MS_TOKEN_KEY = "msSessionToken";
const MS_MAP_ZOOM = 19;
const MS_TAB_PATTERN = "https://ms.gov.ge/msmap/*";


// ---- ms.gov.ge search ----

const MS_NO_SESSION = "ms.gov.ge-ის სესია ვერ მივიღე: გახსენი ms.gov.ge ერთხელ ჩვეულებრივად და სცადე ხელახლა";

async function storedMsToken() {
  const data = await chrome.storage.local.get(MS_TOKEN_KEY);
  return (data[MS_TOKEN_KEY] && data[MS_TOKEN_KEY].token) || null;
}

// Opens ms.gov.ge in a background (inactive) tab so the site creates / renews this browser's
// session; content_ms.js reports the token, the tab closes again. One refresh at a time.
let msTokenRefresh = null;
function refreshMsToken(oldToken) {
  if (msTokenRefresh) return msTokenRefresh;
  msTokenRefresh = (async () => {
    let tab = null;
    try {
      tab = await chrome.tabs.create({ url: `${MS_BASE}/msmap/`, active: false });
      for (let i = 0; i < 40; i++) { // up to ~20 s (the site may go through its login redirect first)
        await new Promise((r) => setTimeout(r, 500));
        const t = await storedMsToken();
        if (t && t !== oldToken) return t;
      }
      return null;
    } catch (err) {
      console.error("ms.gov.ge session refresh failed:", err);
      return null;
    } finally {
      if (tab) chrome.tabs.remove(tab.id).catch(() => {});
      msTokenRefresh = null;
    }
  })();
  return msTokenRefresh;
}

function msSearchRequest(code, token) {
  return fetch(MS_SEARCH_URL, {
    method: "POST",
    headers: { "accept": "*/*", "content-type": "application/json", "sso-token": token },
    body: JSON.stringify({ searchText: code }),
    credentials: "omit"
  });
}

// Returns { code, wkt, appRegNum } or null if the code was not found. Throws on errors.
async function searchMsParcel(code) {
  let token = await storedMsToken();
  if (!token) token = await refreshMsToken(null);
  if (!token) throw new Error(MS_NO_SESSION);
  let res = await msSearchRequest(code, token);
  if (res.status === 401 || res.status === 403) {
    // the session expired or was removed: let the site renew it, then try once more
    const fresh = await refreshMsToken(token);
    if (!fresh) throw new Error(MS_NO_SESSION);
    res = await msSearchRequest(code, fresh);
    if (res.status === 401 || res.status === 403) throw new Error(MS_NO_SESSION);
  }
  if (!res.ok) throw new Error(`სერვერმა დააბრუნა HTTP ${res.status}`);

  let json;
  try {
    json = await res.json();
  } catch {
    throw new Error("პასუხი JSON არ არის (პორტალი შესაძლოა დროებით მიუწვდომელია)");
  }

  const r = json && json.naprSearchResult;
  // Not found = naprSearchResult with all fields null. Exact match only.
  if (!r || r.cadCode !== code) return null;
  if (!r.wktShape) throw new Error(`კოდი ${code} მოიძებნა, მაგრამ გეომეტრია არ დაბრუნდა`);
  return { code: r.cadCode, wkt: r.wktShape, appRegNum: r.appRegNum || "" };
}

// The portal's own link centres on the middle of the parcel's bounding box:
// https://ms.gov.ge/msmap/#C=<lon>-<lat>@Z=<zoom>
function msMapUrl(polygons) {
  let minLon = Infinity, maxLon = -Infinity, minLat = Infinity, maxLat = -Infinity;
  for (const poly of polygons) {
    for (const ring of poly) {
      for (const [lon, lat] of ring) {
        if (lon < minLon) minLon = lon;
        if (lon > maxLon) maxLon = lon;
        if (lat < minLat) minLat = lat;
        if (lat > maxLat) maxLat = lat;
      }
    }
  }
  const lon = ((minLon + maxLon) / 2).toFixed(7);
  const lat = ((minLat + maxLat) / 2).toFixed(7);
  return `${MS_BASE}/msmap/#C=${lon}-${lat}@Z=${MS_MAP_ZOOM}`;
}


// ======================= KML (shared by both maps) =======================

// ---- KML export ----

// WKT "POLYGON ((x y, x y, ...), (hole...))" or "MULTIPOLYGON (((...)), ((...)))"
// -> [ [ring, ring...], ... ]  (one entry per polygon; first ring = outer, rest = holes).
// A ring is an array of [lon, lat].
function parseWktPolygons(wkt) {
  const text = String(wkt || "").trim();
  const m = text.match(/^(MULTIPOLYGON|POLYGON)\s*(?:Z|M|ZM)?\s*(\(.*\))\s*$/is);
  if (!m) throw new Error("გეომეტრიის ფორმატი ვერ ამოვიცანი (მხოლოდ POLYGON/MULTIPOLYGON მხარდაჭერილია)");

  // Pull out every "(...)" group that has no nested parentheses = one ring each,
  // remembering which polygon it belongs to via the nesting depth.
  const polygons = [];
  let depth = 0, buf = "", current = null;
  const isMulti = m[1].toUpperCase() === "MULTIPOLYGON";
  const polyDepth = isMulti ? 2 : 1; // depth at which a polygon's ring list opens
  for (const ch of m[2]) {
    if (ch === "(") {
      depth++;
      if (depth === polyDepth) { current = []; polygons.push(current); }
      buf = "";
    } else if (ch === ")") {
      if (depth === polyDepth + 1) current.push(parseRing(buf));
      depth--;
      buf = "";
    } else {
      buf += ch;
    }
  }
  if (!polygons.length || polygons.some((p) => !p.length)) throw new Error("გეომეტრია ცარიელია");
  return polygons;
}

function parseRing(str) {
  const ring = str.split(",").map((pair) => {
    const nums = pair.trim().split(/\s+/).map(Number);
    if (nums.length < 2 || nums.some((n) => Number.isNaN(n))) throw new Error("კოორდინატის წაკითხვა ვერ მოხერხდა");
    return [nums[0], nums[1]]; // lon, lat (extra Z ignored)
  });
  const a = ring[0], b = ring[ring.length - 1];
  if (a[0] !== b[0] || a[1] !== b[1]) ring.push([a[0], a[1]]); // KML requires closed rings
  return ring;
}

function xmlEscape(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function ringToKml(ring) {
  return ring.map(([lon, lat]) => `${lon},${lat},0`).join(" ");
}

function buildKml(code, address, polygons) {
  const polyXml = polygons.map(([outer, ...holes]) => {
    const inner = holes.map((h) =>
      `\n        <innerBoundaryIs><LinearRing><coordinates>${ringToKml(h)}</coordinates></LinearRing></innerBoundaryIs>`
    ).join("");
    return `      <Polygon>
        <outerBoundaryIs><LinearRing><coordinates>${ringToKml(outer)}</coordinates></LinearRing></outerBoundaryIs>${inner}
      </Polygon>`;
  });
  const geometry = polyXml.length === 1
    ? polyXml[0]
    : `      <MultiGeometry>\n${polyXml.join("\n")}\n      </MultiGeometry>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>${xmlEscape(code)}</name>
    <Style id="parcel">
      <LineStyle><color>ff0000ff</color><width>2</width></LineStyle>
      <PolyStyle><color>400000ff</color></PolyStyle>
    </Style>
    <Placemark>
      <name>${xmlEscape(code)}</name>
      <description>${xmlEscape(address)}</description>
      <styleUrl>#parcel</styleUrl>
${geometry}
    </Placemark>
  </Document>
</kml>
`;
}

// Fetch the parcel's geometry and return { kml, polygons } (null if the code was not found).
async function buildKmlForCode(code) {
  const parcel = await searchParcel(code);
  if (!parcel) return null;

  // Plain string concatenation on purpose: keeps "lr_parcels:ROWID" exactly as the portal sends it
  // (URL.searchParams would re-encode the colon as %3A).
  let geometryUrl = MAP_BASE + parcel.geometryPath;
  if (!/[?&]lang=/.test(geometryUrl)) geometryUrl += "&lang=ka";
  const res = await fetch(geometryUrl, { credentials: "include" });
  if (!res.ok) throw new Error(`გეომეტრიის მოთხოვნამ დააბრუნა HTTP ${res.status}`);

  let json;
  try {
    json = await res.json();
  } catch {
    throw new Error("გეომეტრიის პასუხი JSON არ არის");
  }
  const item = (json.data || []).find((d) => d.name === code) || (json.data || [])[0];
  if (!item || !item.shape) throw new Error("ამ კოდზე გეომეტრია არ დაბრუნდა");
  if (item.shape_format && item.shape_format !== "WKT") throw new Error(`უცნობი გეომეტრიის ფორმატი: ${item.shape_format}`);
  if (item.proj && item.proj !== "EPSG:4326") throw new Error(`მოულოდნელი კოორდინატთა სისტემა: ${item.proj} (მხოლოდ EPSG:4326 მხარდაჭერილია)`);

  const polygons = parseWktPolygons(item.shape);
  return { kml: buildKml(code, parcel.address, polygons), polygons };
}


// ======================= history =======================

const HISTORY_KEY = "history";
const HISTORY_MAX = 10000;
let historyQueue = Promise.resolve(); // serialise writes so parallel jobs don't overwrite each other

function addHistory(action, results) {
  const now = Date.now();
  const rows = results.map((r) => {
    const row = { t: now, action, code: r.code, status: r.status, error: r.error || "" };
    if (r.from) row.from = r.from; // Map Jump: page it came from
    if (r.to) row.to = r.to;       // Map Jump: page it opened
    if (r.place) row.place = r.place; // Map Jump: { lat, lon, zoom, how }
    return row;
  });
  historyQueue = historyQueue.then(async () => {
    const data = await chrome.storage.local.get(HISTORY_KEY);
    const list = (data[HISTORY_KEY] || []).concat(rows);
    await chrome.storage.local.set({ [HISTORY_KEY]: list.slice(-HISTORY_MAX) });
  }).catch((err) => console.error("History write failed:", err));
  return historyQueue;
}

// ---- import (from history.html) ----

// Only known fields, sane lengths, and links that are plain http(s) (a shared file must not be able
// to put e.g. a "javascript:" link into the history page).
function cleanImportedRow(r) {
  if (!r || typeof r !== "object") return null;
  const t = Number(r.t);
  if (!Number.isFinite(t) || t <= 0) return null;
  const str = (v, max) => (typeof v === "string" || typeof v === "number") ? String(v).slice(0, max) : "";
  const action = str(r.action, 40), code = str(r.code, 300), status = str(r.status, 20);
  if (!action || !code || !status) return null;
  const row = { t, action, code, status, error: str(r.error, 500) };
  const url = (v) => (typeof v === "string" && /^https?:\/\//i.test(v)) ? v.slice(0, 3000) : null;
  const from = url(r.from), to = url(r.to);
  if (from) row.from = from;
  if (to) row.to = to;
  const p = r.place;
  if (p && typeof p === "object" && [p.lat, p.lon, p.zoom].every((n) => typeof n === "number" && Number.isFinite(n))) {
    row.place = { lat: p.lat, lon: p.lon, zoom: p.zoom, how: str(p.how, 100) };
  }
  return row;
}

const historyRowKey = (r) => `${r.t}|${r.action}|${r.code}|${r.status}`;

// mode "add": merge, skipping rows that are already there; mode "replace": the file becomes the history.
// markImported: rows get { imported: { file, at } } (shown and filterable as "imported");
// otherwise they count as the user's own rows.
function importHistory(rows, mode, markImported, fileName) {
  let result = { ok: false, error: "უცნობი შეცდომა" };
  historyQueue = historyQueue.then(async () => {
    const existing = mode === "replace" ? [] : ((await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY] || []);
    const seen = new Set(existing.map(historyRowKey));
    const stamp = Date.now();
    let added = 0, skipped = 0, invalid = 0;
    const incoming = [];
    for (const raw of Array.isArray(rows) ? rows : []) {
      const row = cleanImportedRow(raw);
      if (!row) { invalid++; continue; }
      const key = historyRowKey(row);
      if (seen.has(key)) { skipped++; continue; }
      seen.add(key);
      if (markImported) row.imported = { file: String(fileName || "").slice(0, 200), at: stamp };
      incoming.push(row);
      added++;
    }
    const merged = existing.concat(incoming).sort((a, b) => a.t - b.t);
    const dropped = Math.max(0, merged.length - HISTORY_MAX);
    await chrome.storage.local.set({ [HISTORY_KEY]: merged.slice(-HISTORY_MAX) });
    result = { ok: true, added, skipped, invalid, dropped, total: merged.length - dropped };
  }).catch((err) => { result = { ok: false, error: err.message }; });
  return historyQueue.then(() => result);
}

// v2.12/2.13 kept maps.gov.ge history under "mapsHistory" with actions "map"/"kml": move it over once.
function migrateOldHistory() {
  historyQueue = historyQueue.then(async () => {
    const data = await chrome.storage.local.get(["mapsHistory", HISTORY_KEY]);
    if (!data.mapsHistory) return;
    const old = data.mapsHistory.map((r) => ({ ...r, action: r.action === "kml" ? "maps-kml" : r.action === "map" ? "maps-map" : r.action }));
    const merged = old.concat(data[HISTORY_KEY] || []).sort((a, b) => a.t - b.t).slice(-HISTORY_MAX);
    await chrome.storage.local.set({ [HISTORY_KEY]: merged });
    await chrome.storage.local.remove("mapsHistory");
    console.log(`History: moved ${old.length} old maps.gov.ge rows`);
  }).catch((err) => console.error("History migration failed:", err));
  return historyQueue;
}

// Small window listing the codes that were not found (closes with Enter / Esc).
async function showNotice(action, results) {
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const bad = results.filter((r) => r.status !== "found");
  await chrome.storage.session.set({
    ["notice_" + id]: { action, results: results.map(({ code, status, error }) => ({ code, status, error: error || "" })) }
  });
  const width = 460, height = Math.min(600, 230 + 26 * bad.length);
  const opts = { url: `notice.html#${id}`, type: "popup", width, height, focused: true };
  try {
    const w = await chrome.windows.getLastFocused();
    if (w && w.width && w.height) {
      opts.left = Math.max(0, Math.round(w.left + (w.width - width) / 2));
      opts.top = Math.max(0, Math.round(w.top + (w.height - height) / 3));
    }
  } catch (e) { /* default position */ }
  await chrome.windows.create(opts);
}

// Several codes -> notice window; a single code -> plain error text.
async function reportProblems(action, codes, results) {
  const bad = results.filter((r) => r.status !== "found");
  if (!bad.length) return null;
  const anyError = bad.some((r) => r.status === "error");
  flashBadge(codes.length > 1 ? "✗" + bad.length : (anyError ? "!" : "✗"), anyError ? "#b91c1c" : "#b45309");
  if (codes.length > 1) {
    await showNotice(action, results);
    return { notice: true };
  }
  const r = bad[0];
  return { error: r.status === "error" ? r.error : `კოდი ${r.code} ვერ მოიძებნა` };
}

// ======================= map tabs (shared) =======================
// "Add to the open map" always means: the most recently used tab OF THAT SITE.
// A maps.gov.ge command never looks at ms.gov.ge tabs and vice versa.

const MAPS_TAB_PATTERN = "https://maps.gov.ge/map/portal*";

async function findSiteTab(pattern) {
  const tabs = await chrome.tabs.query({ url: pattern });
  if (!tabs.length) return null;
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return tabs[0];
}

// If the tab has no content script yet (open before install/reload), inject it once and retry.
async function sendToContent(tabId, file, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    console.log(`${file} not reachable, injecting:`, err && err.message);
    await chrome.scripting.executeScript({ target: { tabId }, files: [file] });
    return await chrome.tabs.sendMessage(tabId, message);
  }
}

async function focusTab(tab) {
  await chrome.tabs.update(tab.id, { active: true });
  if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
}

// ======================= maps.gov.ge actions =======================
// The portal adds a parcel to its side panel (keeping the previous ones) every time the
// "#search/result/...getinfo.alpha?lbl=..." hash changes; content_maps.js does that in the tab.

async function openMapsMap(codes, newTab) {
  const results = [];
  for (const code of codes) {
    try {
      const parcel = await searchParcel(code);
      results.push(parcel ? { code, status: "found", lbl: parcel.lbl } : { code, status: "missing" });
    } catch (err) {
      results.push({ code, status: "error", error: err.message });
    }
  }
  await addHistory("maps-map", results);
  const items = results.filter((r) => r.status === "found").map((r) => ({ code: r.code, lbl: r.lbl }));

  if (items.length) {
    try {
      const existing = newTab ? null : await findSiteTab(MAPS_TAB_PATTERN);
      if (existing) {
        await focusTab(existing);
        console.log(`[maps-map] adding ${items.map((i) => i.code).join(", ")} to tab ${existing.id}`);
        sendToContent(existing.id, "content_maps.js", { type: "maps-draw", items })
          .then((r) => console.log("[maps-map] draw result:", JSON.stringify(r)))
          .catch((err) => { console.error("Drawing in the open tab failed:", err); flashBadge("!", "#b91c1c"); });
      } else {
        const tab = await chrome.tabs.create({ url: mapsUrlForLbl(items[0].lbl), active: true });
        // the first parcel comes from the URL itself; content_maps.js adds the rest
        await chrome.storage.session.set({ ["pending_maps_" + tab.id]: items });
        if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
      }
    } catch (err) {
      console.error("Opening the maps.gov.ge map failed:", err);
      flashBadge("!", "#b91c1c");
      return { ok: false, error: err.message };
    }
  }
  // the notice window opens after the map tab, so it stays in front
  const problem = await reportProblems("maps-map", codes, results);
  return problem && problem.error ? { ok: false, error: problem.error } : { ok: true };
}

// One <code>.kml file per found code.
async function downloadMapsKml(codes) {
  const results = [];
  for (const code of codes) {
    try {
      const built = await buildKmlForCode(code);
      if (!built) {
        results.push({ code, status: "missing" });
        continue;
      }
      await saveKml(code, built.kml);
      results.push({ code, status: "found" });
    } catch (err) {
      console.error(`maps.gov.ge KML for ${code} failed:`, err);
      results.push({ code, status: "error", error: err.message });
    }
  }
  await addHistory("maps-kml", results);
  const problem = await reportProblems("maps-kml", codes, results);
  return problem && problem.error ? { ok: false, error: problem.error } : { ok: true };
}

// Service workers have no URL.createObjectURL, so the file goes out as a data: URL.
async function saveKml(code, kml) {
  const dataUrl = "data:application/vnd.google-earth.kml+xml;charset=utf-8," + encodeURIComponent(kml);
  await chrome.downloads.download({ url: dataUrl, filename: `${code}.kml`, saveAs: false });
}

// ======================= ms.gov.ge actions =======================
// The site draws a parcel only when its own "registered land parcels" search result is clicked;
// content_ms.js types the code into the site's search box and clicks that row. Outlines accumulate.

async function msLookupAll(codes) {
  const results = [];
  for (const code of codes) {
    try {
      const parcel = await searchMsParcel(code);
      results.push(parcel ? { code, status: "found", wkt: parcel.wkt } : { code, status: "missing" });
    } catch (err) {
      results.push({ code, status: "error", error: err.message });
    }
  }
  return results;
}

async function openMsMap(codes, newTab) {
  const results = await msLookupAll(codes);
  await addHistory("ms-map", results);
  const found = results.filter((r) => r.status === "found");

  if (found.length) {
    try {
      const foundCodes = found.map((r) => r.code);
      const existing = newTab ? null : await findSiteTab(MS_TAB_PATTERN);
      if (existing) {
        await focusTab(existing);
        console.log(`[ms-map] adding ${foundCodes.join(", ")} to tab ${existing.id}`);
        sendToContent(existing.id, "content_ms.js", { type: "ms-draw", codes: foundCodes })
          .then((r) => console.log("[ms-map] draw result:", JSON.stringify(r)))
          .catch((err) => { console.error("Drawing in the open tab failed:", err); flashBadge("!", "#b91c1c"); });
      } else {
        const tab = await chrome.tabs.create({ url: msMapUrl(parseWktPolygons(found[0].wkt)), active: true });
        // content_ms.js in that tab picks the codes up and runs the site's own search
        await chrome.storage.session.set({ ["pending_ms_" + tab.id]: foundCodes });
        if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
      }
    } catch (err) {
      console.error("Opening the ms.gov.ge map failed:", err);
      flashBadge("!", "#b91c1c");
      return { ok: false, error: err.message };
    }
  }
  const problem = await reportProblems("ms-map", codes, results);
  return problem && problem.error ? { ok: false, error: problem.error } : { ok: true };
}

async function downloadMsKml(codes) {
  const results = await msLookupAll(codes);
  for (const r of results) {
    if (r.status !== "found") continue;
    try {
      await saveKml(r.code, buildKml(r.code, "", parseWktPolygons(r.wkt)));
    } catch (err) {
      console.error(`ms.gov.ge KML for ${r.code} failed:`, err);
      r.status = "error";
      r.error = "KML ვერ შეიქმნა: " + err.message;
    }
  }
  await addHistory("ms-kml", results);
  const problem = await reportProblems("ms-kml", codes, results);
  return problem && problem.error ? { ok: false, error: problem.error } : { ok: true };
}

// ======================= registry (PDF / extract page) and auction =======================

// The extract PDF (GetBlob) link from the cad_amo.php page; falls back to that page itself.
async function resolvePdf(cadCode) {
  const pageUrl = BASE_URL + encodeURIComponent(cadCode);
  try {
    const response = await fetch(pageUrl);
    const htmlText = await response.text();
    const trMatches = htmlText.match(/<tr[^>]*>([\s\S]*?)<\/tr>/gi) || [];
    for (const tr of trMatches) {
      if (tr.includes("ამონაწერი")) {
        const match = tr.match(/openWindow\('([^']+)'\)/i);
        if (match && match[1]) return { url: match[1], status: "found" };
      }
    }
    return { url: pageUrl, status: "missing", error: "PDF ამონაწერი ვერ მოიძებნა, გაიხსნა ამონაწერების გვერდი" };
  } catch (err) {
    console.error("Failed to fetch/parse NAPR HTML:", err);
    return { url: pageUrl, status: "error", error: "გვერდი ვერ წავიკითხე, გაიხსნა ამონაწერების გვერდი" };
  }
}

// mode: "pdf" | "abstract" | "auction"
async function processAndOpen(value, mode) {
  let targetUrl, status = "opened", error = "";
  if (mode === "auction") {
    targetUrl = AUCTION_URL + encodeURIComponent(value);
  } else if (mode === "pdf") {
    ({ url: targetUrl, status, error = "" } = await resolvePdf(value));
  } else {
    targetUrl = BASE_URL + encodeURIComponent(value);
  }
  await addHistory(mode, [{ code: value, status, error }]);
  const tab = await chrome.tabs.create({ url: targetUrl, active: true });
  if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
  return { ok: true };
}

// ======================= one entry point for every action =======================

const MAP_ACTIONS = ["maps-map", "maps-kml", "ms-map", "ms-kml"];

async function runAction(action, text, newTab = false) {
  if (action === "auction") {
    const id = extractAuctionId(text);
    if (!id) return { ok: false, error: "ლოტის ნომერი ვერ ამოვიცანი" };
    return processAndOpen(id, "auction");
  }
  if (action === "pdf" || action === "abstract") {
    const code = extractValidCadastralCode(text) || (text ? text.trim() : "");
    if (!code) return { ok: false, error: "კოდის ფორმატი ვერ ამოვიცანი" };
    return processAndOpen(code, action);
  }
  const codes = extractAllCadastralCodes(text);
  if (!codes.length) {
    flashBadge("?", "#b45309");
    return { ok: false, error: "კოდის ფორმატი ვერ ამოვიცანი" };
  }
  if (action === "maps-map") return openMapsMap(codes, newTab);
  if (action === "maps-kml") return downloadMapsKml(codes);
  if (action === "ms-map") return openMsMap(codes, newTab);
  if (action === "ms-kml") return downloadMsKml(codes);
  return { ok: false, error: "უცნობი მოქმედება: " + action };
}

// ======================= where the text comes from =======================

async function readClipboardViaOffscreen() {
  try {
    const hasDoc = await chrome.offscreen.hasDocument();
    if (!hasDoc) {
      await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: [chrome.offscreen.Reason.CLIPBOARD],
        justification: "Read cadastral code from system clipboard"
      });
    }

    const text = await chrome.runtime.sendMessage({
      target: "offscreen-doc",
      type: "get-clipboard-data"
    });

    return text ? text.trim() : "";
  } catch (err) {
    console.error("Clipboard read failed:", err);
    return "";
  }
}


function getPageSelection() {
  const sel = window.getSelection();
  if (sel && sel.toString().trim()) {
    return sel.toString().trim();
  }
  if (document.activeElement && document.activeElement.value) {
    const el = document.activeElement;
    return el.value.substring(el.selectionStart, el.selectionEnd).trim();
  }
  return "";
}


// Chrome focused -> the active tab's selection; another app focused (Word, PDF reader...) -> nothing,
// so the caller uses the clipboard (a leftover selection in Chrome must not win over a fresh copy).
async function readActiveSelection(action) {
  try {
    const lastWin = await chrome.windows.getLastFocused();
    const chromeFocused = !!(lastWin && lastWin.focused);
    console.log(`[${action}] Chrome focused: ${chromeFocused}`);
    if (!chromeFocused) return "";
    const [activeTab] = await chrome.tabs.query({ active: true, windowId: lastWin.id });
    if (!activeTab || !activeTab.id || !activeTab.url) return "";
    const url = activeTab.url;
    if (url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("https://chromewebstore.google.com")) return "";
    const results = await chrome.scripting.executeScript({ target: { tabId: activeTab.id }, func: getPageSelection });
    return (results && results[0] && results[0].result) || "";
  } catch (e) {
    console.log("Selection read skipped/failed:", e);
    return "";
  }
}

// Map/KML actions need a cadastral code: a selection without one falls back to the clipboard too.
async function getTextForCommand(action) {
  const selection = await readActiveSelection(action);
  const needsCode = MAP_ACTIONS.includes(action);
  if (selection && (!needsCode || extractAllCadastralCodes(selection).length)) {
    console.log(`[${action}] source=selection`);
    return selection;
  }
  console.log(`[${action}] source=clipboard`);
  return readClipboardViaOffscreen();
}

// ======================= menus, shortcuts, messages =======================

const MENU_ITEMS = [
  { id: "maps-map", title: "maps.gov.ge · რუკაზე დამატება: '%s'" },
  { id: "maps-map-new", title: "maps.gov.ge · ახალ ტაბში: '%s'" },
  { id: "maps-kml", title: "maps.gov.ge · KML: '%s'" },
  { type: "separator", id: "sep1" },
  { id: "ms-map", title: "ms.gov.ge · რუკაზე დამატება: '%s'" },
  { id: "ms-map-new", title: "ms.gov.ge · ახალ ტაბში: '%s'" },
  { id: "ms-kml", title: "ms.gov.ge · KML: '%s'" },
  { type: "separator", id: "sep2" },
  { id: "pdf", title: "რეესტრი · PDF ამონაწერი: '%s'" },
  { id: "abstract", title: "რეესტრი · ამონაწერების გვერდი: '%s'" },
  { id: "auction", title: "აუქციონი · ლოტი: '%s'" }
];

chrome.runtime.onInstalled.addListener(() => {
  migrateOldHistory();
  chrome.contextMenus.removeAll(() => {
    for (const item of MENU_ITEMS) {
      chrome.contextMenus.create(item.type === "separator"
        ? { id: item.id, type: "separator", contexts: ["selection"] }
        : { id: item.id, title: item.title, contexts: ["selection"] });
    }
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (!info.selectionText) return;
  const id = String(info.menuItemId);
  const newTab = id.endsWith("-new");
  runAction(newTab ? id.slice(0, -4) : id, info.selectionText, newTab);
});

// Command ids of the shortcuts (kept from earlier versions so existing key bindings survive).
const COMMAND_ACTIONS = {
  "lookup-cadastral-map": ["maps-map", false],
  "lookup-cadastral-map-new-tab": ["maps-map", true],
  "lookup-cadastral-kml": ["maps-kml", false],
  "ms-open-map": ["ms-map", false],
  "ms-open-map-new-tab": ["ms-map", true],
  "ms-save-kml": ["ms-kml", false],
  "lookup-cadastral-pdf": ["pdf", false],
  "lookup-cadastral-abstract": ["abstract", false],
  "lookup-auction-lot": ["auction", false]
};

chrome.commands.onCommand.addListener(async (command) => {
  const entry = COMMAND_ACTIONS[command];
  if (!entry) return;
  const [action, newTab] = entry;
  const text = await getTextForCommand(action);
  if (!text) {
    flashBadge("?", "#b45309");
    return;
  }
  const result = await runAction(action, text, newTab);
  if (result && !result.ok) console.warn(`[${action}]`, result.error);
});

// content_ms.js -> background: this browser's own ms.gov.ge session token (kept only locally)
chrome.runtime.onMessage.addListener((message, sender) => {
  if (!message || message.type !== "ms-token") return;
  if (!sender.url || !sender.url.startsWith(MS_BASE + "/")) return;
  const token = String(message.token || "");
  if (!/^[\w-]+\.[\w-]+\.[\w-]+$/.test(token) || token.length > 4000) return;
  storedMsToken().then((current) => {
    if (current !== token) chrome.storage.local.set({ [MS_TOKEN_KEY]: { token, at: Date.now() } });
  });
});

// History page -> background: import a history file
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "history-import") return;
  importHistory(message.rows, message.mode === "replace" ? "replace" : "add", !!message.markImported, message.fileName)
    .then(sendResponse);
  return true;
});

// Popup -> background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "run") return;
  runAction(message.action, message.text || "", !!message.newTab).then(sendResponse);
  return true; // keep the channel open for the async response
});

// The content scripts ask once per page load: "was this tab opened for some codes?" (answered once)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !sender.tab) return;
  const prefix = message.type === "maps-get-pending" ? "pending_maps_"
               : message.type === "ms-get-pending" ? "pending_ms_" : null;
  if (!prefix) return;
  const key = prefix + sender.tab.id;
  (async () => {
    for (let i = 0; i < 10; i++) { // the tab can load before the key is written
      const data = await chrome.storage.session.get(key);
      if (data[key]) {
        await chrome.storage.session.remove(key);
        return sendResponse(data[key]);
      }
      await new Promise((r) => setTimeout(r, 200));
    }
    sendResponse(null);
  })();
  return true;
});

// ======================= Map Jump: the same place on another map =======================
// Reads the place shown in the active tab (maps.gov.ge, ms.gov.ge or Google Maps) and opens it
// on one of the other two maps, always in a new tab. Not written to the history.

const DEFAULT_ZOOM = 18;
const clampZoom = (z) => Math.min(20, Math.max(3, Math.round(z)));
const SITE_NAMES = { maps: "maps.gov.ge", ms: "ms.gov.ge", google: "Google Maps" };


function detectSite(url) {
  if (/^https:\/\/maps\.gov\.ge\/map\/portal/.test(url)) return "maps";
  if (/^https:\/\/ms\.gov\.ge\/msmap\//.test(url)) return "ms";
  if (/^https:\/\/(www\.)?google\.[a-z.]+\/maps/.test(url)) return "google";
  return null;
}

// ---- reading the place from a URL ----

// ms.gov.ge keeps the map centre in the hash and updates it on every move: #C=<lon>-<lat>@Z=<zoom>
function parseMsUrl(url) {
  const m = url.match(/#C=(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)@Z=(\d+(?:\.\d+)?)/);
  return m ? { lon: +m[1], lat: +m[2], zoom: +m[3], how: "რუკის ცენტრი" } : null;
}

// Google: ".../@<lat>,<lng>,<N>z" or ",<N>m" (satellite view, metres of visible height).
// A searched / dropped pin is in the data part as "!3d<lat>!4d<lng>" - that is the exact place, so it wins.
function parseGoogleUrl(url, viewportHeight) {
  const view = url.match(/@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)(?:,(\d+(?:\.\d+)?)([zm]))?/);
  const pins = [...url.matchAll(/!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)/g)];
  if (!view && !pins.length) return null;
  let zoom = DEFAULT_ZOOM;
  if (view && view[3]) zoom = view[4] === "z" ? +view[3] : metersToZoom(+view[3], +view[1], viewportHeight);
  if (pins.length) {
    const p = pins[pins.length - 1];
    return { lat: +p[1], lon: +p[2], zoom, how: "ქინძისთავი" };
  }
  return { lat: +view[1], lon: +view[2], zoom, how: "რუკის ცენტრი" };
}

// Visible height in metres -> web-map zoom level (same scale on all three maps).
function metersToZoom(meters, lat, heightPx) {
  const h = heightPx || 900;
  return Math.log2((156543.03392 * Math.cos((lat * Math.PI) / 180) * h) / meters);
}

// maps.gov.ge writes "#state/point=<lon>,<lat>&...&zoom=<z>" when the map is moved or clicked.
function parseMapsStateUrl(url) {
  const m = url.match(/#state\/point=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/);
  if (!m) return null;
  const z = url.match(/[&?]zoom=(\d+(?:\.\d+)?)/);
  return { lon: +m[1], lat: +m[2], zoom: z ? +z[1] : DEFAULT_ZOOM, how: "რუკის ცენტრი / დაკლიკებული წერტილი" };
}

// "44.806938, 41.714521" (lon, lat) under the mouse - only if it looks like geographic degrees
// inside Georgia (another projection, e.g. UTM metres, is ignored).
function parseMapsPointer(text) {
  const m = (text || "").match(/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/);
  if (!m) return null;
  const lon = +m[1], lat = +m[2];
  if (lon < 39 || lon > 47.5 || lat < 40.5 || lat > 44) return null;
  return { lon, lat };
}

async function readMapsPointer(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: "jump-read-pointer" });
    return parseMapsPointer(r && r.text);
  } catch (e) {
    return null; // tab opened before the extension was installed/reloaded: no content script
  }
}

// While a parcel is shown (".../getinfo.alpha?lbl=...&share=1") maps.gov.ge stops updating the
// address, so the place is taken from that parcel instead: the centre of its outline.
function mapsLblFromUrl(url) {
  const m = url.match(/getinfo\.alpha\?lbl=([^&#]+)/);
  if (!m) return null;
  try { return decodeURIComponent(m[1]); } catch { return m[1]; } // keeps "+" as "+"
}

async function mapsParcelLocation(lbl) {
  // the ROWID goes out exactly as the portal sends it (a literal "+", never %2B)
  const res = await fetch(`${MAP_BASE}/lr/bo/mg/getinfo.alpha?lbl=${lbl}&res=shp&lang=ka`, { credentials: "include" });
  if (!res.ok) throw new Error(`maps.gov.ge: HTTP ${res.status}`);
  const json = await res.json();
  const item = (json.data || [])[0];
  if (!item || !item.shape) throw new Error("maps.gov.ge: ნაკვეთის გეომეტრია ვერ მივიღე");
  const nums = (item.shape.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
  let minLon = Infinity, maxLon = -Infinity, minLat = Infinity, maxLat = -Infinity;
  for (let i = 0; i + 1 < nums.length; i += 2) {
    minLon = Math.min(minLon, nums[i]); maxLon = Math.max(maxLon, nums[i]);
    minLat = Math.min(minLat, nums[i + 1]); maxLat = Math.max(maxLat, nums[i + 1]);
  }
  if (!isFinite(minLon)) throw new Error("maps.gov.ge: ნაკვეთის გეომეტრია ცარიელია");
  return { lon: (minLon + maxLon) / 2, lat: (minLat + maxLat) / 2, zoom: 19, how: `ნაკვეთი ${item.name || ""}`.trim() };
}

// { site, lat, lon, zoom, how } for a tab, or throws with a readable reason.
async function getLocation(tab) {
  const url = (tab && tab.url) || "";
  const site = detectSite(url);
  if (!site) throw new Error("აქტიური ტაბი არ არის maps.gov.ge, ms.gov.ge ან Google Maps რუკა");
  let loc = null;
  if (site === "ms") loc = parseMsUrl(url);
  else if (site === "google") loc = parseGoogleUrl(url, tab.height);
  else {
    // 1) the point under the mouse (shortcut pressed while hovering the map)
    // 2) the shown parcel's centre, or 3) the map centre / clicked point from the address
    const pointer = await readMapsPointer(tab.id);
    const state = parseMapsStateUrl(url);
    if (pointer) {
      loc = { ...pointer, zoom: state ? state.zoom : 19, how: "მაუსის წერტილი" };
    } else {
      const lbl = mapsLblFromUrl(url);
      loc = lbl ? await mapsParcelLocation(lbl) : state;
    }
  }
  if (!loc) throw new Error(`${SITE_NAMES[site]}: ადგილი ვერ განვსაზღვრე (გადაადგილე ან დააკლიკე რუკას და სცადე თავიდან)`);
  return { site, ...loc };
}

// ---- opening the place on a target map (always in a new tab) ----

const fixed = (n) => n.toFixed(7);

function msTargetUrl(loc) {
  return `https://ms.gov.ge/msmap/#C=${fixed(loc.lon)}-${fixed(loc.lat)}@Z=${clampZoom(loc.zoom)}`;
}

// "/place/<lat>,<lng>" puts a pin on the exact point; "!3m1!1e3" = satellite view.
function googleTargetUrl(loc) {
  const ll = `${fixed(loc.lat)},${fixed(loc.lon)}`;
  return `https://www.google.com/maps/place/${ll}/@${ll},${clampZoom(loc.zoom)}z/data=!3m1!1e3`;
}

// maps.gov.ge opens at a point from its address only together with "&share=1&layers=92,97"
// (without them the portal ignores "state/point" and shows the whole country).
// Zoom 20 = what the site's own coordinate search ends up with.
function mapsPointUrl(loc, zoom = 20) {
  return `${MAP_BASE}/map/portal#state/point=${fixed(loc.lon)},${fixed(loc.lat)}&projection=EPSG:4326&zoom=${zoom}&projection=EPSG:4326&share=1&layers=92,97`;
}

// Opens { lat, lon, zoom } on the target map in a new tab; returns the address for the history.
async function openTarget(target, loc) {
  if (target === "ms" || target === "google") {
    const url = target === "ms" ? msTargetUrl(loc) : googleTargetUrl(loc);
    await chrome.tabs.create({ url, active: true });
    return url;
  }
  // The jump itself still uses the site's coordinate search (content_jump_maps.js), because that
  // also drops a pin on the point; the history gets the equivalent "state/point...&share=1" link.
  const newTab = await chrome.tabs.create({ url: `${MAP_BASE}/map/portal`, active: true });
  await chrome.storage.session.set({ ["pending_jump_" + newTab.id]: { lon: loc.lon, lat: loc.lat } });
  return mapsPointUrl(loc);
}

async function jumpTo(target, tab) {
  const from = (tab && tab.url) || "";
  const fromSite = detectSite(from);
  const route = `${fromSite ? SITE_NAMES[fromSite] : "?"} → ${SITE_NAMES[target]}`;
  let loc;
  try {
    loc = await getLocation(tab);
  } catch (err) {
    flashBadge("?", "#b45309");
    if (fromSite) await addHistory("jump-" + target, [{ code: route, status: "error", error: err.message, from }]);
    return { ok: false, error: err.message };
  }
  if (loc.site === target) return { ok: false, error: `უკვე ${SITE_NAMES[target]}-ზე ხარ` };

  console.log(`[jump] ${loc.site} -> ${target}:`, JSON.stringify(loc));
  const to = await openTarget(target, loc);
  const place = { lat: +loc.lat.toFixed(7), lon: +loc.lon.toFixed(7), zoom: Math.round(loc.zoom), how: loc.how };
  // maps.gov.ge's own address only reopens the view with "&share=1&layers=92,97" (and it does not
  // follow the mouse point), so for that site the history keeps a link to the exact place used;
  // a shown parcel keeps its parcel link, which already works.
  const fromLink = loc.site === "maps" && !String(loc.how).startsWith("ნაკვეთი")
    ? mapsPointUrl(loc, Math.round(loc.zoom))
    : from;
  await addHistory("jump-" + target, [{ code: route, status: "opened", from: fromLink, to, place }]);
  return { ok: true, loc };
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab;
}

// ---- shortcuts, popup, content script ----

const COMMAND_TARGETS = { "jump-to-maps": "maps", "jump-to-ms": "ms", "jump-to-google": "google" };

chrome.commands.onCommand.addListener(async (command) => {
  const target = COMMAND_TARGETS[command];
  if (!target) return;
  const r = await jumpTo(target, await activeTab());
  if (!r.ok) console.warn("[jump]", r.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;
  if (message.type === "jump-info") {
    chrome.tabs.get(message.tabId)
      .then((tab) => getLocation(tab))
      .then((loc) => sendResponse({ ok: true, loc }), (err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (message.type === "jump-reopen" && message.place) {
    openTarget(message.target, message.place).then(() => sendResponse({ ok: true }), (err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (message.type === "jump") {
    chrome.tabs.get(message.tabId).then((tab) => jumpTo(message.target, tab)).then(sendResponse);
    return true;
  }
  if (message.type === "jump-get-pending" && sender.tab) {
    const key = "pending_jump_" + sender.tab.id;
    (async () => {
      for (let i = 0; i < 10; i++) { // the tab can load before the key is written
        const data = await chrome.storage.session.get(key);
        if (data[key]) {
          await chrome.storage.session.remove(key);
          return sendResponse(data[key]);
        }
        await new Promise((r) => setTimeout(r, 200));
      }
      sendResponse(null);
    })();
    return true;
  }
});

// ======================= self-update of the unpacked install =======================
// install.bat / updater.ps1 replace this extension's files on disk (manifest.json last).
// An unpacked extension serves its files straight from disk, so a newer version number in the
// manifest file means new files are in place: reload to start using them. (Store installs never
// change on disk, so this does nothing there.)
async function checkForNewFiles() {
  try {
    const res = await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" });
    const disk = await res.json();
    const running = chrome.runtime.getManifest().version;
    if (disk && disk.version && disk.version !== running) {
      console.log(`[self-update] ${running} -> ${disk.version}: reloading`);
      chrome.runtime.reload();
    }
  } catch (e) {
    console.log("[self-update] check skipped:", e && e.message);
  }
}
chrome.alarms.create("check-new-files", { periodInMinutes: 10 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "check-new-files") checkForNewFiles();
});
checkForNewFiles();
