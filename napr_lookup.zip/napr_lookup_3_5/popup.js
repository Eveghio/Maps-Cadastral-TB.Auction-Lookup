const input = document.getElementById("code");
const msg = document.getElementById("msg");

// Everything runs in background.js (runAction); the popup only shows errors.
function run(action, newTab) {
  msg.style.color = "#555";
  msg.textContent = "ვეძებ...";
  chrome.runtime.sendMessage({ type: "run", action, text: input.value, newTab }, (res) => {
    if (chrome.runtime.lastError || !res) {
      msg.style.color = "#c62828";
      msg.textContent = "შეცდომა: პასუხი ვერ მივიღე";
      return;
    }
    if (res.ok) return window.close();
    msg.style.color = "#c62828";
    msg.textContent = res.error;
  });
}

for (const btn of document.querySelectorAll("button[data-action]")) {
  btn.addEventListener("click", (e) => {
    const action = btn.dataset.action;
    const canNewTab = action === "maps-map" || action === "ms-map";
    run(action, canNewTab && (btn.dataset.new === "1" || e.shiftKey));
  });
}
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    run("maps-map", e.shiftKey);
  }
});
document.getElementById("historyLink").addEventListener("click", (e) => {
  e.preventDefault();
  openHistoryPage().then(() => window.close());
});
// "This place ->": the place shown in the active tab, opened on another map
const JUMP_NAMES = { maps: "maps.gov.ge", ms: "ms.gov.ge", google: "Google Maps" };
(async () => {
  const info = document.getElementById("jumpInfo");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  chrome.runtime.sendMessage({ type: "jump-info", tabId: tab.id }, (res) => {
    if (chrome.runtime.lastError || !res || !res.ok) {
      info.className = "err";
      info.textContent = (res && res.error) || "ადგილი ვერ განვსაზღვრე";
      return;
    }
    const l = res.loc;
    info.textContent = `${JUMP_NAMES[l.site]} · ${l.how} · ${l.lat.toFixed(6)}, ${l.lon.toFixed(6)} · ზუმი ${Math.round(l.zoom)}`;
    for (const b of document.querySelectorAll("button[data-jump]")) {
      const target = b.dataset.jump;
      b.disabled = target === l.site;
      b.onclick = () => {
        msg.textContent = "";
        chrome.runtime.sendMessage({ type: "jump", target, tabId: tab.id }, (r) => {
          if (r && r.ok) window.close();
          else { msg.style.color = "#c62828"; msg.textContent = (r && r.error) || "შეცდომა"; }
        });
      };
    }
  });
})();
input.focus();
