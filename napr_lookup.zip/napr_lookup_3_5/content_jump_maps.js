// maps.gov.ge tab opened by Map Jump: search the coordinates with the site's own search box.
(() => {
  if (window.__mapJumpLoaded) return;
  window.__mapJumpLoaded = true;

  // The coordinates line in the bottom bar follows the mouse while it is over the map and is
  // empty otherwise. Read it at the moment of the request (no memory of old positions).
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "jump-read-pointer") return;
    const el = document.querySelector("div.p-3.font-thin.font-monospace");
    sendResponse({ text: el ? el.textContent.trim() : "" });
  });

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const waitFor = async (fn, timeoutMs) => {
    for (let t = 0; t < timeoutMs; t += 250) {
      const v = fn();
      if (v) return v;
      await sleep(250);
    }
    return null;
  };

  (async () => {
    let loc = null;
    try {
      loc = await chrome.runtime.sendMessage({ type: "jump-get-pending" });
    } catch (e) {
      return;
    }
    if (!loc) return; // not opened by Map Jump

    // the map is ready once the site writes its default "#state/..." address
    await waitFor(() => location.hash.startsWith("#state/"), 20000);
    const box = await waitFor(() => document.querySelector("input#search_box"), 10000);
    const btn = document.querySelector("#search_button");
    if (!box || !btn) return console.warn("[map-jump] search box not found");

    box.value = `${loc.lon.toFixed(7)},${loc.lat.toFixed(7)}`;
    box.dispatchEvent(new Event("input", { bubbles: true }));
    box.dispatchEvent(new Event("change", { bubbles: true }));
    btn.click();
    console.log("[map-jump] searched", box.value);
  })();
})();
