const HISTORY_KEY = "history";
const PREFS_KEY = "historyViewPrefs"; // remembered filters/sort (this browser only)
const el = (id) => document.getElementById(id);
let all = [];

// Empty set = "no filter" (everything shown); ticking chips narrows the list.
const state = { actions: new Set(), statuses: new Set(), sources: new Set(), text: "", sort: "t", dir: -1 };
const SOURCE_LABELS = { own: "ჩემი", imported: "იმპორტირებული" };
const sourceOf = (r) => (r.imported ? "imported" : "own");

function savePrefs() {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify({ actions: [...state.actions], statuses: [...state.statuses], sources: [...state.sources], sort: state.sort, dir: state.dir }));
  } catch (e) { /* storage unavailable: just don't remember */ }
}
function loadPrefs() {
  try {
    const p = JSON.parse(localStorage.getItem(PREFS_KEY) || "null");
    if (!p) return;
    state.actions = new Set((p.actions || []).filter((a) => a in ACTIONS));
    state.statuses = new Set((p.statuses || []).filter((s) => s in STATUS_LABELS));
    state.sources = new Set((p.sources || []).filter((s) => s in SOURCE_LABELS));
    if (["t", "action", "code", "status"].includes(p.sort)) state.sort = p.sort;
    if (p.dir === 1 || p.dir === -1) state.dir = p.dir;
  } catch (e) { /* ignore */ }
}

function chip(label, checked, color, onChange) {
  const l = document.createElement("label");
  l.className = "chip" + (checked ? " on" : "");
  if (color) l.style.setProperty("--c", color);
  const cb = document.createElement("input");
  cb.type = "checkbox";
  cb.checked = checked;
  cb.addEventListener("change", () => {
    l.classList.toggle("on", cb.checked);
    onChange(cb.checked);
  });
  l.append(cb, document.createTextNode(label));
  return l;
}

function toggle(set, value, on) {
  if (on) set.add(value); else set.delete(value);
  savePrefs();
  render();
}

function buildFilters() {
  const ac = el("actionChips");
  ac.textContent = "";
  // grouped by site, coloured like the popup rows
  for (const site of Object.keys(SITES)) {
    const actions = Object.keys(ACTIONS).filter((a) => ACTIONS[a].site === site);
    if (!actions.length) continue;
    const g = document.createElement("span");
    g.className = "group";
    g.style.setProperty("--c", SITES[site].color);
    const n = document.createElement("span");
    n.className = "gname";
    n.textContent = SITES[site].label;
    g.appendChild(n);
    for (const a of actions) g.appendChild(chip(ACTIONS[a].name, state.actions.has(a), SITES[site].color, (on) => toggle(state.actions, a, on)));
    ac.appendChild(g);
  }
  const sc = el("statusChips");
  sc.textContent = "";
  for (const s of Object.keys(STATUS_LABELS)) sc.appendChild(chip(STATUS_LABELS[s], state.statuses.has(s), null, (on) => toggle(state.statuses, s, on)));
  const src = el("sourceChips");
  src.textContent = "";
  for (const s of Object.keys(SOURCE_LABELS)) src.appendChild(chip(SOURCE_LABELS[s], state.sources.has(s), s === "imported" ? "#5e35b1" : null, (on) => toggle(state.sources, s, on)));
}

// everything the text filter looks at (code / route, links, coordinates)
function haystack(r) {
  const p = r.place ? `${r.place.lat}, ${r.place.lon} ${r.place.how || ""}` : "";
  return `${r.code} ${r.from || ""} ${r.to || ""} ${p}`.toLowerCase();
}

// Older rows kept maps.gov.ge "#state/point=..." links without "&share=1&layers=92,97",
// which the site opens without moving to the point: complete them when shown.
function workingLink(url) {
  if (url && url.startsWith("https://maps.gov.ge/map/portal#state/point=") && !/[&?]share=1/.test(url)) {
    return url + "&share=1&layers=92,97";
  }
  return url;
}

// Map Jump rows: route, place, short links (+ full links on demand) in the code cell
function fillJumpCell(cell, r) {
  cell.textContent = "";
  const route = document.createElement("div");
  route.className = "route";
  route.textContent = r.code;
  cell.appendChild(route);
  if (r.place) {
    const p = document.createElement("div");
    p.className = "place";
    p.textContent = `${r.place.lat}, ${r.place.lon} · ზუმი ${r.place.zoom} · ${r.place.how}`;
    cell.appendChild(p);
  }
  if (!r.from && !r.to) return;
  const links = document.createElement("div");
  links.className = "links";
  const link = (label, url, onClick) => {
    const a = document.createElement("a");
    a.textContent = label;
    a.href = url;
    a.title = url;
    a.target = "_blank";
    a.rel = "noopener";
    if (onClick) a.addEventListener("click", onClick);
    links.appendChild(a);
  };
  if (r.from) link("საიდან ↗", workingLink(r.from));
  if (r.to) {
    // rows from v3.2/3.3 stored only ".../map/portal" for maps.gov.ge: re-open those through the
    // extension (coordinate search); newer rows carry a working "state/point...&share=1" link
    const oldMapsRow = r.action === "jump-maps" && r.place && !r.to.includes("#state/point");
    const reopen = oldMapsRow
      ? (e) => { e.preventDefault(); chrome.runtime.sendMessage({ type: "jump-reopen", target: "maps", place: r.place }); }
      : null;
    link("სად ↗", r.to, reopen);
  }
  const toggle = document.createElement("button");
  toggle.className = "toggle";
  toggle.textContent = "ლინკები ▾";
  const full = document.createElement("div");
  full.className = "full";
  full.hidden = true;
  const line = (label, url) => {
    const d = document.createElement("div");
    const b = document.createElement("b");
    b.textContent = label + " ";
    d.append(b, document.createTextNode(url));
    full.appendChild(d);
  };
  if (r.from) line("საიდან:", workingLink(r.from));
  if (r.to) line("სად:", r.action === "jump-maps" && r.place && !r.to.includes("#state/point") ? `${r.to}  (ძიება: ${r.place.lon},${r.place.lat})` : r.to);
  toggle.addEventListener("click", () => {
    full.hidden = !full.hidden;
    toggle.textContent = full.hidden ? "ლინკები ▾" : "ლინკები ▴";
  });
  links.appendChild(toggle);
  cell.append(links, full);
}

function sortValue(r, key) {
  if (key === "action") return actionLabel(r.action);
  if (key === "status") return STATUS_LABELS[r.status] || r.status;
  return r[key];
}

// the rows the current filters let through, in the current sort order
function filteredRows() {
  const text = state.text;
  const rows = all.filter((r) =>
    (!state.actions.size || state.actions.has(r.action)) &&
    (!state.statuses.size || state.statuses.has(r.status)) &&
    (!state.sources.size || state.sources.has(sourceOf(r))) &&
    (!text || haystack(r).includes(text.toLowerCase()))
  );
  // stable sort; ties keep newest first
  rows.sort((a, b) => {
    const va = sortValue(a, state.sort), vb = sortValue(b, state.sort);
    const c = typeof va === "number" ? va - vb : String(va).localeCompare(String(vb), "ka", { numeric: true });
    return c !== 0 ? c * state.dir : b.t - a.t;
  });
  return rows;
}

function render() {
  const rows = filteredRows();
  const tbody = el("rows");
  tbody.textContent = "";
  for (const r of rows) {
    const tr = document.createElement("tr");
    const td = (cls, txt) => { const c = document.createElement("td"); if (cls) c.className = cls; c.textContent = txt; tr.appendChild(c); return c; };
    const timeCell = td("time", formatTime(r.t));
    if (r.imported) {
      const b = document.createElement("span");
      b.className = "imp";
      b.textContent = "იმპორტი";
      b.title = `ფაილი: ${r.imported.file || "?"}\nიმპორტირდა: ${formatTime(r.imported.at)}`;
      timeCell.appendChild(b);
    }
    const act = td("act", actionLabel(r.action));
    act.style.color = actionColor(r.action);
    const codeCell = td("code", r.code);
    if (String(r.action).startsWith("jump-")) fillJumpCell(codeCell, r);
    const res = td(r.status, STATUS_LABELS[r.status] || r.status);
    if (r.error) {
      const e = document.createElement("div");
      e.className = "errtext";
      e.textContent = r.error;
      res.appendChild(e);
    }
    tbody.appendChild(tr);
  }
  el("empty").hidden = rows.length > 0;
  el("count").textContent = `ნაჩვენებია ${rows.length} / სულ ${all.length}`;
  for (const th of document.querySelectorAll("th[data-sort]")) {
    th.querySelector(".arrow").textContent = th.dataset.sort === state.sort ? (state.dir === 1 ? "▲" : "▼") : "";
  }
}

async function load() {
  all = (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY] || [];
  render();
}

for (const th of document.querySelectorAll("th[data-sort]")) {
  th.addEventListener("click", () => {
    const key = th.dataset.sort;
    if (state.sort === key) state.dir = -state.dir;
    else { state.sort = key; state.dir = key === "t" ? -1 : 1; }
    savePrefs();
    render();
  });
}
el("text").addEventListener("input", () => { state.text = el("text").value.trim(); render(); });
el("reset").addEventListener("click", () => {
  state.actions.clear();
  state.statuses.clear();
  state.sources.clear();
  state.text = "";
  el("text").value = "";
  savePrefs();
  buildFilters();
  render();
});
el("clear").addEventListener("click", async () => {
  if (!all.length) return;
  if (!confirm(`წაიშალოს ისტორიის ყველა ჩანაწერი (${all.length})?`)) return;
  await chrome.storage.local.remove(HISTORY_KEY);
});
// ---------- export / import ----------

function say(text, isError = false) {
  const n = el("note");
  n.className = isError ? "err" : "";
  n.textContent = text;
}

// Small modal with radio-button questions. Resolves to { groupName: value } or null (cancelled).
function askDialog({ title, info, groups, okText }) {
  return new Promise((resolve) => {
    el("dlgTitle").textContent = title;
    const body = el("dlgBody");
    body.textContent = "";
    if (info) {
      const p = document.createElement("p");
      p.textContent = info;
      body.appendChild(p);
    }
    for (const g of groups) {
      const fs = document.createElement("fieldset");
      const lg = document.createElement("legend");
      lg.textContent = g.label;
      fs.appendChild(lg);
      for (const o of g.options) {
        const l = document.createElement("label");
        const r = document.createElement("input");
        r.type = "radio";
        r.name = g.name;
        r.value = o.value;
        r.checked = !!o.checked;
        l.append(r, document.createTextNode(" " + o.text));
        fs.appendChild(l);
      }
      body.appendChild(fs);
    }
    el("dlgOk").textContent = okText;
    el("overlay").hidden = false;
    const done = (ok) => {
      el("overlay").hidden = true;
      document.removeEventListener("keydown", onKey);
      el("dlgOk").onclick = el("dlgCancel").onclick = null;
      if (!ok) return resolve(null);
      const out = {};
      for (const g of groups) out[g.name] = (body.querySelector(`input[name="${g.name}"]:checked`) || {}).value;
      resolve(out);
    };
    const onKey = (e) => {
      if (e.key === "Escape") done(false);
      else if (e.key === "Enter") { e.preventDefault(); done(true); }
    };
    document.addEventListener("keydown", onKey);
    el("dlgOk").onclick = () => done(true);
    el("dlgCancel").onclick = () => done(false);
    el("dlgOk").focus();
  });
}

el("export").addEventListener("click", async () => {
  if (!all.length) return say("ისტორია ცარიელია, გასატანი არაფერია", true);
  const shown = filteredRows();
  let rows = all;
  if (shown.length !== all.length) {
    const a = await askDialog({
      title: "ისტორიის ექსპორტი",
      groups: [{ name: "what", label: "რა გავიტანო?", options: [
        { value: "all", text: `მთელი ისტორია (${all.length})`, checked: true },
        { value: "shown", text: `მხოლოდ ნაჩვენები, ფილტრის მიხედვით (${shown.length})` }] }],
      okText: "ექსპორტი"
    });
    if (!a) return;
    if (a.what === "shown") rows = shown;
  }
  // "imported" marks are not exported: whoever imports the file decides that for themselves
  const data = {
    format: "napr-lookup-history",
    version: 1,
    exportedAt: new Date().toISOString(),
    count: rows.length,
    rows: rows.map(({ imported, ...r }) => r).sort((a, b) => a.t - b.t)
  };
  const d = new Date(), p = (n) => String(n).padStart(2, "0");
  const name = `napr-history-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}.json`;
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 1)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  say(`გატანილია ${rows.length} ჩანაწერი: ${name}`);
});

el("import").addEventListener("click", () => el("importFile").click());
el("importFile").addEventListener("change", async () => {
  const file = el("importFile").files[0];
  if (!file) return;
  let data;
  try {
    data = JSON.parse(await file.text());
  } catch (e) {
    el("importFile").value = "";
    return say(`${file.name}: ფაილი ვერ წავიკითხე (JSON არ არის)`, true);
  }
  el("importFile").value = ""; // the same file can be chosen again later
  const rows = Array.isArray(data) ? data
    : (data && data.format === "napr-lookup-history" && Array.isArray(data.rows)) ? data.rows : null;
  if (!rows) return say(`${file.name}: ეს არ არის ამ ექსთენშენის ისტორიის ფაილი`, true);
  if (!rows.length) return say(`${file.name}: ფაილში ჩანაწერი არ არის`, true);

  const times = rows.map((r) => r && Number(r.t)).filter((t) => Number.isFinite(t) && t > 0);
  const range = times.length ? ` · ${formatTime(Math.min(...times)).slice(0, 10)} – ${formatTime(Math.max(...times)).slice(0, 10)}` : "";
  const ans = await askDialog({
    title: `იმპორტი: ${file.name}`,
    info: `ფაილში ${rows.length} ჩანაწერია${range}`,
    groups: [
      { name: "mode", label: "როგორ შევიდეს?", options: [
        { value: "add", text: "დაემატოს არსებულ ისტორიას (ზუსტი დუბლიკატები გამოტოვდება)", checked: true },
        { value: "replace", text: `სრულად ჩაანაცვლოს არსებული ისტორია (წაიშლება ${all.length} ჩანაწერი)` }] },
      { name: "mark", label: "მოინიშნოს, რომ იმპორტირებულია?", options: [
        { value: "yes", text: "კი: ექნება ნიშანი „იმპორტი“ და ცალკე გაიფილტრება", checked: true },
        { value: "no", text: "არა: ჩაითვლება ჩემ ჩანაწერებად" }] }
    ],
    okText: "იმპორტი"
  });
  if (!ans) return;
  if (ans.mode === "replace" && all.length && !confirm(`ნამდვილად წაიშალოს არსებული ${all.length} ჩანაწერი და მის ნაცვლად ჩაიწეროს ფაილი?`)) return;

  const res = await new Promise((resolve) => chrome.runtime.sendMessage(
    { type: "history-import", rows, mode: ans.mode, markImported: ans.mark === "yes", fileName: file.name }, resolve));
  if (!res || !res.ok) return say("იმპორტი ვერ მოხერხდა: " + ((res && res.error) || "პასუხი ვერ მივიღე"), true);
  const parts = [`${ans.mode === "replace" ? "ისტორია ჩანაცვლდა" : "დაემატა"}: ${res.added} ჩანაწერი`];
  if (res.skipped) parts.push(`დუბლიკატი გამოტოვდა: ${res.skipped}`);
  if (res.invalid) parts.push(`არასწორი ჩანაწერი გამოტოვდა: ${res.invalid}`);
  if (res.dropped) parts.push(`ლიმიტის (10 000) გამო წაიშალა უძველესი: ${res.dropped}`);
  say(parts.join(" · "));
});

// refresh live while the page is open
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && HISTORY_KEY in changes) load();
});

loadPrefs();
buildFilters();
load();
